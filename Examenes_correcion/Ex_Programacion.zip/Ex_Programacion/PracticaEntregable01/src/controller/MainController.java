package controller;

import java.util.List;

import controller.model.IModel;
import controller.model.ModelMemory;
import controller.model.entities.Components;
import controller.view.IMainView;
import controller.view.MainTerminalView;

public class MainController {
    private IModel model;
    private IMainView mainView;
    
    public MainController() {
        this.model = new ModelMemory();
        this.mainView = new MainTerminalView();
    }
    
    public void run() {
    
        manageInventory();
        
        
        if (mainView.confirmInventory()) {
            showComponentsToCustomer();
        } else {
            mainView.showMessage("Proceso cancelado por el usuario.");
        }
    }
    
    private void manageInventory() {
        int option;
        
        mainView.showMessage("MODO ADMINISTRADOR: Gestión de inventario");
        
        do {
            option = mainView.inventoryMenu();
            switch(option) {
                case 0: 
                    mainView.showMessage("Finalizando gestión de inventario...");
                    break;
                    
                case 1: 
                    List<Components> list = model.list();
                    mainView.list(list);
                    break;
                    
                case 2: 
                    Components car = mainView.add();
                    model.add(car);
                    break;
                    
                case 3: 
                    List<Components> listForEdit = model.list();
                    mainView.list(listForEdit);

                    String elementForEdit = mainView.selectElementComponents();
                    Components carForEdit = model.findByElement(elementForEdit);

                    if (carForEdit != null) {
                        Components modifiedComponents = mainView.editComponents(carForEdit);
                        model.updateComponents(elementForEdit, modifiedComponents);
                    } else {
                        mainView.showMessage("No se encontró ningún componente con esa matrícula.");
                    }
                    break;
                    
                case 4: 
                    List<Components> listForDelete = model.list();
                    mainView.list(listForDelete); 

                    String elementToDelete = mainView.selectComponentsToDelete();
                    Components carToDelete = model.findByElement(elementToDelete);

                    if (carToDelete != null) { 
                        if (mainView.confirmDelete()) { 
                            model.delete(elementToDelete);
                            mainView.showMessage("Componente eliminado correctamente.");
                        } else {
                            mainView.showMessage("Eliminación cancelada.");
                        }
                    } else {
                        mainView.showMessage("No se encontró ningún componente con ese nombre.");
                    }
                    break;
                    
                default:
                    mainView.showMessage("Opción no válida.");
            }
        } while (option != 0);
    }
    
    private void showComponentsToCustomer() {
        int option;
        
        mainView.showMessage("MODO CLIENTE: Selección de compra");
        
        do {
            option = mainView.customerMenu();
            switch(option) {
                case 0: 
                    mainView.exit();
                    break;
                    
                case 1: 
                    List<Components> list = model.list();
                    mainView.list(list);
                    break;
                    
                case 2: 
                    List<Components> availableComponentss = model.list();
                    mainView.list(availableComponentss);
                    
                    if (!availableComponentss.isEmpty()) {
                        String selectedElement = mainView.selectElementComponents();
                        Components selectedComponents = model.findByElement(selectedElement);
                        
                        if (selectedComponents != null) {
                            mainView.showComponentsDetails(selectedComponents);
                            if (mainView.confirmPurchase()) {
                                mainView.completePurchase(selectedComponents);
                            }
                        } else {
                            mainView.showMessage("No se encontró ningún componente con esa matrícula.");
                        }
                    } else {
                        mainView.showMessage("No hay componente disponibles.");
                    }
                    break;
                    
                default:
                    mainView.showMessage("Opción no válida.");
            }
        } while (option != 0);
    }
    
}
