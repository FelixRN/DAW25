package controller.view;

import java.util.List;

import controller.model.entities.Components;
import controller.utils.TerminalUtils;

public class MainTerminalView implements IMainView {

    @Override
    public int inventoryMenu() {
        int option;
        
        TerminalUtils.output("\n===== GESTIÓN DE INVENTARIO =====");
        TerminalUtils.output("1.- Listar productos disponibles");
        TerminalUtils.output("2.- Añadir producto");
        TerminalUtils.output("3.- Editar producto");
        TerminalUtils.output("4.- Eliminar producto");
        TerminalUtils.output("0.- Finalizar gestión de inventario");
        TerminalUtils.output("Seleccione una opción: ");
        
        try {
            option = TerminalUtils.inputInt();
        } catch (Exception e) {
            option = -1;
        }
        
        return option;
    }
    
    @Override
    public int customerMenu() {
        int option;
        
        TerminalUtils.output("\n===== Almacen de productos =====");
        TerminalUtils.output("1.- Ver todos los productos disponibles");
        TerminalUtils.output("2.- Seleccionar un producto");
        TerminalUtils.output("0.- Salir");
        TerminalUtils.output("Seleccione una opción: ");
        
        try {
            option = TerminalUtils.inputInt();
        } catch (Exception e) {
            option = -1;
        }
        
        return option;
    }

    @Override
    public void exit() {
        TerminalUtils.output("Gracias por su visita!");
    }

    @Override
    public void list(List<Components> list) {
        if (list.isEmpty()) {
            TerminalUtils.output("No hay productos disponibles.");
            return;
        }
        
        TerminalUtils.output("\n=== LISTA DE Productos DISPONIBLES ===");
        TerminalUtils.output("Productos - Cantidad");
        
        for(Components components : list) {
            TerminalUtils.output(components.toString());
        }
        
        TerminalUtils.output("Total de Productos: " + list.size());
    }
    
    @Override
    public Components add() {
        TerminalUtils.output("\n=== AÑADIR NUEVO Productos ===");
        TerminalUtils.output("Introduzca el Producto:");
        String element = TerminalUtils.inputText();

        TerminalUtils.output("Introduzca la cantidad:");
        String quantity = TerminalUtils.inputText();
        
        Components components = new Components(element, quantity);
        TerminalUtils.output("Producto añadido correctamente.");
        return components;
    }
    
    @Override
    public void showMessage(String message) {
        TerminalUtils.output(message);
    }
    
    @Override
    public String selectElementComponents() {
        TerminalUtils.output("Introduzca el producto:");
        String element = TerminalUtils.inputText();
        return element;
    }

    @Override
    public Components editComponents(Components componentsForEdit) {
        TerminalUtils.output("\n=== EDITAR COMPONENTE ===");
        TerminalUtils.output("Editando producto: " + componentsForEdit.toString());

        TerminalUtils.output("Introduzca el nuevo producto (deje vacío para mantener la actual):");
        String element = TerminalUtils.inputText();
        if(isValidString(element)) {
            componentsForEdit.setElement(element);
        }

        TerminalUtils.output("Introduzca la cantidad (deje vacío para mantener el actual):");
        String quantity = TerminalUtils.inputText();
        if(isValidString(quantity)) {
            componentsForEdit.setQuantity(quantity);
        }
        
        TerminalUtils.output("Coche actualizado correctamente.");
        return componentsForEdit;
    }
    
    public boolean isValidString(String value) {
        return value != null && !value.isEmpty() && !value.isBlank();
    }
    
    @Override
    public String selectComponentsToDelete() {
        TerminalUtils.output("Introduzca el producto que desea eliminar:");
        return TerminalUtils.inputText();
    }
    
    @Override
    public boolean confirmDelete() {
        TerminalUtils.output("¿Está seguro de que desea eliminar este producto? (si/no):");
        String respuesta = TerminalUtils.inputText();
        return respuesta.equalsIgnoreCase("si");
    }
    
    @Override
    public String getText() {
        return TerminalUtils.inputText();
    }
    
    @Override
    public boolean confirmInventory() {
        TerminalUtils.output("\n=== CONFIRMACIÓN DE INVENTARIO ===");
        TerminalUtils.output("¿El inventario está completo y listo para mostrar a los clientes? (si/no):");
        String respuesta = TerminalUtils.inputText();
        return respuesta.equalsIgnoreCase("si");
    }
    
    @Override
    public void showComponentsDetails(Components components) {
        TerminalUtils.output("\n=== DETALLES DEL COMPONENTE SELECCIONADO ===");
        TerminalUtils.output("Producto: " + components.getElement());
        TerminalUtils.output("Cantidad: " + components.getQuantity());
        // Se podrá añadir más detalles a futuro
    }
    
    @Override
    public boolean confirmPurchase() {
        TerminalUtils.output("¿Desea adquirir este producto? (si/no):");
        String respuesta = TerminalUtils.inputText();
        return respuesta.equalsIgnoreCase("si");
    }
    
    @Override
    public void completePurchase(Components components) {
        TerminalUtils.output("\n=== ¡FELICIDADES! ===");
        TerminalUtils.output("Ha adquirido el producto: " + components.toString());
        TerminalUtils.output("Nuestro equipo se pondrá en contacto con usted para finalizar el trámite.");
        TerminalUtils.output("Gracias por confiar en ProductosPeruanos!.");
    }

	@Override
	public int mainMenu() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void edit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}
}