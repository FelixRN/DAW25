package controller.model.entities;

public class Components {
	private String element;
	private String quantity;
	
	public Components(String element, String quantity) {
		super();
		this.element = element;
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return this.element + " - " + this.quantity;
	}
	
	@Override
	public Components clone() {
		return new Components(this.element, this.quantity);
	}

	public String getElement() {
		return this.element;
	}

	public void setElement(String element) {
		this.element = element;
	}
	
	public String getModel() {
        return this.quantity;
    }
    
    public void setModel(String model) {
        this.quantity = model;
    }

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getQuantity() {
		// TODO Auto-generated method stub
		return null;
	}
}
